{
    "name": "Serial Printer Catálogo",
    "version": "1.0",
    "category": "Sales",
    "summary": "Gestión de marcas externas para catálogo",
    "author": "Serial Printer",
    "depends": ["base"],
    "data": [
        "views/toptex_brand_views.xml"
    ],
    "installable": True,
    "application": True,
    "auto_install": False
}
